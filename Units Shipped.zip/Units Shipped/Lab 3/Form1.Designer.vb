﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmUnitsShipped
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.components = New System.ComponentModel.Container()
		Me.lblDayCount = New System.Windows.Forms.Label()
		Me.lblUnits = New System.Windows.Forms.Label()
		Me.txtUnitInput = New System.Windows.Forms.TextBox()
		Me.lblEmployee1 = New System.Windows.Forms.Label()
		Me.lblEmployee2 = New System.Windows.Forms.Label()
		Me.lblEmployee3 = New System.Windows.Forms.Label()
		Me.txtEmployee1 = New System.Windows.Forms.TextBox()
		Me.txtEmployee2 = New System.Windows.Forms.TextBox()
		Me.txtEmployee3 = New System.Windows.Forms.TextBox()
		Me.lblEmployee1Average = New System.Windows.Forms.Label()
		Me.lblEmployee2Average = New System.Windows.Forms.Label()
		Me.lblEmployee3Average = New System.Windows.Forms.Label()
		Me.lblTotalAverage = New System.Windows.Forms.Label()
		Me.btnEnter = New System.Windows.Forms.Button()
		Me.btnReset = New System.Windows.Forms.Button()
		Me.btnExit = New System.Windows.Forms.Button()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
		Me.SuspendLayout()
		'
		'lblDayCount
		'
		Me.lblDayCount.AutoSize = True
		Me.lblDayCount.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
		Me.lblDayCount.Location = New System.Drawing.Point(12, 9)
		Me.lblDayCount.Name = "lblDayCount"
		Me.lblDayCount.Size = New System.Drawing.Size(53, 20)
		Me.lblDayCount.TabIndex = 0
		Me.lblDayCount.Text = "Day 1"
		'
		'lblUnits
		'
		Me.lblUnits.AutoSize = True
		Me.lblUnits.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
		Me.lblUnits.Location = New System.Drawing.Point(12, 43)
		Me.lblUnits.Name = "lblUnits"
		Me.lblUnits.Size = New System.Drawing.Size(58, 20)
		Me.lblUnits.TabIndex = 1
		Me.lblUnits.Text = "Units: "
		'
		'txtUnitInput
		'
		Me.txtUnitInput.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
		Me.txtUnitInput.Location = New System.Drawing.Point(76, 40)
		Me.txtUnitInput.Name = "txtUnitInput"
		Me.txtUnitInput.Size = New System.Drawing.Size(67, 26)
		Me.txtUnitInput.TabIndex = 1
		Me.ToolTip1.SetToolTip(Me.txtUnitInput, "Enter units shipped here")
		'
		'lblEmployee1
		'
		Me.lblEmployee1.AutoSize = True
		Me.lblEmployee1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
		Me.lblEmployee1.Location = New System.Drawing.Point(41, 88)
		Me.lblEmployee1.Name = "lblEmployee1"
		Me.lblEmployee1.Size = New System.Drawing.Size(96, 20)
		Me.lblEmployee1.TabIndex = 3
		Me.lblEmployee1.Text = "Employee 1"
		'
		'lblEmployee2
		'
		Me.lblEmployee2.AutoSize = True
		Me.lblEmployee2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
		Me.lblEmployee2.Location = New System.Drawing.Point(197, 88)
		Me.lblEmployee2.Name = "lblEmployee2"
		Me.lblEmployee2.Size = New System.Drawing.Size(96, 20)
		Me.lblEmployee2.TabIndex = 4
		Me.lblEmployee2.Text = "Employee 2"
		'
		'lblEmployee3
		'
		Me.lblEmployee3.AutoSize = True
		Me.lblEmployee3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
		Me.lblEmployee3.Location = New System.Drawing.Point(353, 88)
		Me.lblEmployee3.Name = "lblEmployee3"
		Me.lblEmployee3.Size = New System.Drawing.Size(96, 20)
		Me.lblEmployee3.TabIndex = 6
		Me.lblEmployee3.Text = "Employee 3"
		'
		'txtEmployee1
		'
		Me.txtEmployee1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
		Me.txtEmployee1.Location = New System.Drawing.Point(27, 111)
		Me.txtEmployee1.Multiline = True
		Me.txtEmployee1.Name = "txtEmployee1"
		Me.txtEmployee1.ReadOnly = True
		Me.txtEmployee1.Size = New System.Drawing.Size(127, 159)
		Me.txtEmployee1.TabIndex = 2
		Me.txtEmployee1.TabStop = False
		'
		'txtEmployee2
		'
		Me.txtEmployee2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
		Me.txtEmployee2.Location = New System.Drawing.Point(183, 111)
		Me.txtEmployee2.Multiline = True
		Me.txtEmployee2.Name = "txtEmployee2"
		Me.txtEmployee2.ReadOnly = True
		Me.txtEmployee2.Size = New System.Drawing.Size(127, 159)
		Me.txtEmployee2.TabIndex = 3
		Me.txtEmployee2.TabStop = False
		'
		'txtEmployee3
		'
		Me.txtEmployee3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
		Me.txtEmployee3.Location = New System.Drawing.Point(339, 111)
		Me.txtEmployee3.Multiline = True
		Me.txtEmployee3.Name = "txtEmployee3"
		Me.txtEmployee3.ReadOnly = True
		Me.txtEmployee3.Size = New System.Drawing.Size(127, 159)
		Me.txtEmployee3.TabIndex = 4
		Me.txtEmployee3.TabStop = False
		'
		'lblEmployee1Average
		'
		Me.lblEmployee1Average.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblEmployee1Average.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!)
		Me.lblEmployee1Average.Location = New System.Drawing.Point(16, 273)
		Me.lblEmployee1Average.Name = "lblEmployee1Average"
		Me.lblEmployee1Average.Size = New System.Drawing.Size(150, 32)
		Me.lblEmployee1Average.TabIndex = 11
		Me.lblEmployee1Average.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'lblEmployee2Average
		'
		Me.lblEmployee2Average.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblEmployee2Average.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!)
		Me.lblEmployee2Average.Location = New System.Drawing.Point(172, 273)
		Me.lblEmployee2Average.Name = "lblEmployee2Average"
		Me.lblEmployee2Average.Size = New System.Drawing.Size(150, 32)
		Me.lblEmployee2Average.TabIndex = 12
		Me.lblEmployee2Average.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'lblEmployee3Average
		'
		Me.lblEmployee3Average.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblEmployee3Average.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!)
		Me.lblEmployee3Average.Location = New System.Drawing.Point(334, 273)
		Me.lblEmployee3Average.Name = "lblEmployee3Average"
		Me.lblEmployee3Average.Size = New System.Drawing.Size(137, 32)
		Me.lblEmployee3Average.TabIndex = 13
		Me.lblEmployee3Average.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'lblTotalAverage
		'
		Me.lblTotalAverage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblTotalAverage.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
		Me.lblTotalAverage.Location = New System.Drawing.Point(27, 318)
		Me.lblTotalAverage.Name = "lblTotalAverage"
		Me.lblTotalAverage.Size = New System.Drawing.Size(439, 32)
		Me.lblTotalAverage.TabIndex = 14
		Me.lblTotalAverage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'btnEnter
		'
		Me.btnEnter.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
		Me.btnEnter.Location = New System.Drawing.Point(27, 357)
		Me.btnEnter.Name = "btnEnter"
		Me.btnEnter.Size = New System.Drawing.Size(141, 30)
		Me.btnEnter.TabIndex = 5
		Me.btnEnter.Text = "&Enter"
		Me.ToolTip1.SetToolTip(Me.btnEnter, "Click to enter data")
		Me.btnEnter.UseVisualStyleBackColor = True
		'
		'btnReset
		'
		Me.btnReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
		Me.btnReset.Location = New System.Drawing.Point(176, 357)
		Me.btnReset.Name = "btnReset"
		Me.btnReset.Size = New System.Drawing.Size(141, 30)
		Me.btnReset.TabIndex = 6
		Me.btnReset.Text = "&Reset"
		Me.ToolTip1.SetToolTip(Me.btnReset, "Click to reset the application")
		Me.btnReset.UseVisualStyleBackColor = True
		'
		'btnExit
		'
		Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
		Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
		Me.btnExit.Location = New System.Drawing.Point(325, 357)
		Me.btnExit.Name = "btnExit"
		Me.btnExit.Size = New System.Drawing.Size(141, 30)
		Me.btnExit.TabIndex = 7
		Me.btnExit.Text = "&Close"
		Me.ToolTip1.SetToolTip(Me.btnExit, "Click to exit the application")
		Me.btnExit.UseVisualStyleBackColor = True
		'
		'frmUnitsShipped
		'
		Me.AcceptButton = Me.btnEnter
		Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.CancelButton = Me.btnExit
		Me.ClientSize = New System.Drawing.Size(483, 404)
		Me.Controls.Add(Me.btnExit)
		Me.Controls.Add(Me.btnReset)
		Me.Controls.Add(Me.btnEnter)
		Me.Controls.Add(Me.lblTotalAverage)
		Me.Controls.Add(Me.lblEmployee3Average)
		Me.Controls.Add(Me.lblEmployee2Average)
		Me.Controls.Add(Me.lblEmployee1Average)
		Me.Controls.Add(Me.txtEmployee3)
		Me.Controls.Add(Me.txtEmployee2)
		Me.Controls.Add(Me.txtEmployee1)
		Me.Controls.Add(Me.lblEmployee3)
		Me.Controls.Add(Me.lblEmployee2)
		Me.Controls.Add(Me.lblEmployee1)
		Me.Controls.Add(Me.txtUnitInput)
		Me.Controls.Add(Me.lblUnits)
		Me.Controls.Add(Me.lblDayCount)
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.Name = "frmUnitsShipped"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "Units Shipped By Employee"
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub

	Friend WithEvents lblDayCount As Label
	Friend WithEvents lblUnits As Label
	Friend WithEvents txtUnitInput As TextBox
	Friend WithEvents lblEmployee1 As Label
	Friend WithEvents lblEmployee2 As Label
	Friend WithEvents lblEmployee3 As Label
	Friend WithEvents txtEmployee1 As TextBox
	Friend WithEvents txtEmployee2 As TextBox
	Friend WithEvents txtEmployee3 As TextBox
	Friend WithEvents lblEmployee1Average As Label
	Friend WithEvents lblEmployee2Average As Label
	Friend WithEvents lblEmployee3Average As Label
	Friend WithEvents lblTotalAverage As Label
	Friend WithEvents btnEnter As Button
	Friend WithEvents btnReset As Button
	Friend WithEvents btnExit As Button
	Friend WithEvents ToolTip1 As ToolTip
End Class
