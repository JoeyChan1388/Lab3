﻿' Name: Joey Chan
' Modified: February 26th, 2020
' Purpose: Take an input for each day of the week for each employee and display them in the textboxes.
' Then calculate an average for each employee and eventually the grand average.

Option Strict On
Public Class frmUnitsShipped
    ' Declaration of arrays.
    Dim outputLabels As Label()
    Dim outputTextboxes As TextBox()
    Dim unitsShipped(2, 6) As Double

    ' Declaration of variables.
    Dim employee As Int32 = 0
    Dim totalUnits As Double = 0
    Dim grandTotalUnits As Double = 0
    Dim day As Int32 = 0

    'Make a constant for the amount of days in a week
    Const WeekDays = 7

    ' The Form load handler gets the lists of textboxes and 
    ' labels when the form loads.
    Private Sub frmUnitsShipped_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Create the arrays of textboxes and labels for easy use later on.
        outputLabels = {lblEmployee1Average, lblEmployee2Average, lblEmployee3Average, lblTotalAverage}
        outputTextboxes = {txtEmployee1, txtEmployee2, txtEmployee3}
    End Sub

    ' This is what happens when the enter button is clicked
    ' It will do the calculations as well as check and make sure
    ' the input entered by the user is valid, then move on to
    ' the next day or employee
    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click
        ' Check to see if the textbox has valid input, then empty the textbox for new entry and move to the next day.
        ValidateTextbox(txtUnitInput)
        txtUnitInput.Text = String.Empty
        lblDayCount.Text = "Day " + (day + 1).ToString

        'If the last day of the week is inputted then return the day to 1 and calculate the average.
        If day > (WeekDays - 1) Then
            outputLabels(employee).Text = "Average: " & Math.Round((totalUnits / 7), 2)
            lblDayCount.Text = "Day 1"

            day = 0
            totalUnits = 0
            employee += 1
        End If

        ' If all the boxes are filled then make the input textbox read only and calculate the average.
        If employee > 2 Then
            btnEnter.Enabled = False
            txtUnitInput.ReadOnly = True
            lblTotalAverage.Text = "Average: " & Math.Round((grandTotalUnits / 21), 2)
        End If
    End Sub

    ' If the reset button is clicked it will set everything to its default 
    ' state through the Default Sub.
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        ' Set everything back to defaults
        SetDefaults()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' Closes the form
        Me.Close()
    End Sub


    ' The default sub when called, will return the form to the state it was in 
    ' when it was first loaded.
    Sub SetDefaults()
        ' Each label that had output in it becomes empty.
        For Each label In outputLabels
            label.Text = String.Empty
        Next

        ' Each textbox that had output in it becomes empty.
        For Each textbox In outputTextboxes
            textbox.Text = String.Empty
        Next

        ' If any input was in the textbox, it clears it away.
        txtUnitInput.Text = String.Empty
        ' Reset all variables to 0
        grandTotalUnits = 0
        totalUnits = 0
        day = 0
        employee = 0
        lblDayCount.Text = "Day 1"

        ' Reset all values in array to 0
        For Each unit In unitsShipped
            unit = 0
        Next

        ' Reset all controls
        txtUnitInput.ReadOnly = False
        btnEnter.Enabled = True
    End Sub

    ' When called, this will check the textbox that was passed through and determine 
    ' if whatever entered is error free and add it to the array if it is.
    Sub ValidateTextbox(textbox As TextBox)
        Dim units As Double
        ' Check if the input from the textbox is a valid numeric number.
        If Double.TryParse(textbox.Text, units) And units >= 0 And units <= 5000 Then
            ' If its valid add the input to the array, then display it on a new line in the output box.
            unitsShipped(employee, day) = units
            outputTextboxes(employee).Text &= units.ToString & vbCrLf

            ' Make the day increase for the next input and add the input to the totals.
            day += 1
            totalUnits += units
            grandTotalUnits += units
        Else
            ' If input is invalid show a message box with an error message.
            MessageBox.Show("Units Shipped must be numeric and between 0 and 5000!")
            textbox.Focus()
        End If
    End Sub
End Class
